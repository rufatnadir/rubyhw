﻿# script_17_02.rb
# Display result of both conditions (true and false) of the logical operator or using following variables:  a, b

a = 5
b = 0
if a == 5 or b == 3; then puts "a or b Not zero"; else puts "a or b Is zero"; end
if a == 0 or b == 5; then puts "a or b Not zero"; else puts "a or b Is zero"; end
