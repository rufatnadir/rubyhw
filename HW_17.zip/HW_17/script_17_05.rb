﻿# script_17_05.rb
# Display result of both conditions (true and false) of the logical operator ! using following variable:  a

a = 5

if !(a == 6); then puts "True condition: a == 6 is false"; else puts "False condition: a == 6 is true"; end
if !(a == 5); then puts "True condition: a == 5 is false"; else puts "False condition: a == 5 is true"; end