﻿# script_17_01.rb
# Display result of both conditions (true and false) of the logical operator and using following variables:  a, b

a = 10
b = 3

if a == 10 and b == 3; then puts "a == 10 and b == 3 is Correct"; else puts "a == 10 and b == 3 is Not Correct"; end
if a == 3 and b == 10; then puts "a == 3 and b == 10 is Correct"; else puts "a == 3 and b == 10 is Not Correct"; end
