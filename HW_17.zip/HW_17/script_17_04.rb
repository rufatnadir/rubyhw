﻿# script_17_04.rb
# Display result of both conditions (true and false) of the logical operator || using following variables:  a, b

a = 10
b = 55

if a == 10 || b == 34; then puts "One of operands is non zero"; else puts "Both operands are zero"; end
if a == 11 || b == 55; then puts "One of operands is non zero"; else puts "Both operands are zero"; end
if a == 12 || b == 34; then puts "One of operands is non zero"; else puts "Both operands are zero"; end