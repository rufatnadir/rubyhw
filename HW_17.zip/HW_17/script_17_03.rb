﻿# script_17_03.rb
# Display result of both conditions (true and false) of the logical operator && using following variables:  a, b

a = 5
b = 3
if a == 5 && b == 3; then puts "a==5 && b==3 is true"; else puts "a==5 && b==3 is false"; end
if a == 5 && b == 2; then puts "a==5 && b==2 is true"; else puts "a==5 && b==2 is false"; end
