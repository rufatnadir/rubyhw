﻿# script_17_06.rb
# Display result of both conditions (true and false) of the logical operator not using following variables:  a

a = 10

if a != 5; then puts "A not equal 5"; else puts "A equal 5"; end
if a != 10; then puts "A not equal 10"; else puts "A equal 10"; end
