﻿# script_14_02.rb
# Display result of the subtraction operation using following variables:  a, b

a = 10
b = 3
result = a / b

puts "Result of subtraction #{a} and #{b} is #{result}"