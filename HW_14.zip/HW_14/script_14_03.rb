﻿# script_14_03.rb
# Display result of the multiplication operation using following variables:  a, b

a= 34
b = 43
result  = a * b

puts "Result of multiplication #{a} and #{b} is #{result}"