﻿# script_14_06.rb
# Display result of the exponent operation (first variable in power on second variable) using following variables: a, b

a = 3
b = 5
result = 3**5

puts "Exponent operation: #{a} in power on #{b} is #{result}"