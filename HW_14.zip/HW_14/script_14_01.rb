﻿# script_14_01.rb
# Display result of the addition operation using following variables:  a, b

a = 10
b = 3
result = a + b
puts "Result of the addition #{a} and #{b} is: #{result}"