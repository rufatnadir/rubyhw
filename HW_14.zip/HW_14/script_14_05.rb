﻿# script_14_05.rb
# Display result of the modulus operation using following variables:  a, b

a = 10
b = 3
result = a % b

puts "Result of modulus for #{a} and #{b} is #{result}"
