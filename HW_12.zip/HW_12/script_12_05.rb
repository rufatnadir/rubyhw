﻿# script_12_05.rb
# Using "puts" display the following statement and its result:  What is 11 times 6? (11 times 6 is ???)

puts "What is 11 times 6?"; puts 11*6
