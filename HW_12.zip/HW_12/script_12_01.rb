﻿#	script_12_01.rb
#	Using "puts" display the following:  3 + 2 + 1 - 5 + 4 % 2 - 1 / 4 + 6

puts "3 + 2 + 1 - 5 + 4 \% 2 - 1 / 4 + 6"
