﻿# script_12_10.rb
# Using "print" display the result of the following (true of false):  3 + 2 < 5 - 7 is …

print "3 + 2 < 5 - 7 is "; print 3+2 < 5-7