﻿# script_12_09.rb
# Using "puts" display the result of the following (true of false):  Is it true 2 less than 5?

puts "Is it true 2 less than 5?"; puts 2 < 5
