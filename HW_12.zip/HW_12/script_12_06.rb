﻿# script_12_06.rb
# Using "print" display how many Roosters:  100 - 25 * 3 % 4 (Roosters - ???)

print 100 - 25 * 3 % 4
