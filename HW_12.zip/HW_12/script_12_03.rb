﻿# script_12_03.rb
# Using "puts" display the following statement and its result:  What is 3 + 2? (3 + 2 is ???)

puts "What is 3 + 2?"; puts 3+2
