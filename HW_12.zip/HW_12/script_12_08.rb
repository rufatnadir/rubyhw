﻿# script_12_08.rb
# Using "puts" display the result of the following (true of false):  Is it true 5 greater than 10?

puts "Is it true 5 greater than 10?"; puts 5>10
