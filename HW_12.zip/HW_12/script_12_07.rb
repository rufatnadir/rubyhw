﻿# script_12_07.rb
# Using "print" display how many Hens:  25 + 30 / 6 (Hens - ???)

print 25 + 30 / 6
