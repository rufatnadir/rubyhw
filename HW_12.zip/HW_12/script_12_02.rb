﻿# script_12_02.rb
# Using " puts " display result of following:  3 + 2 + 1 - 5 + 4 % 2 - 1 / 4 + 6

puts 3 + 2 + 1 - 5 + 4 % 2 - 1 / 4 + 6