﻿# script_12_04.rb
# Using "puts" display the following statement and its result:  What is 5 - 7? (5 - 7 is ???)

puts "What is 5 - 7?"; puts 5-7