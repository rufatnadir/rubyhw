﻿# script_11_06.rb
# Using "puts" display statement – This statement contains " double quote

puts "This statement contains \" double quote"