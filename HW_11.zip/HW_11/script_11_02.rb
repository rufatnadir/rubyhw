﻿# script_11_02.rb
# Using "print" display statement – Hello World!

print "Hello World!"
