﻿# script_11_10.rb
# Using "puts" and * (asterisk) repeat this statement twice – This statement it repeat itself twice!

puts "This statement repeat itself twice! "*2