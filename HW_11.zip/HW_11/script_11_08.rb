﻿# script_11_08.rb
# Using "puts" display statement – This statement contains " double quote and ' single quote

puts "This statement contains \" double quote and \' single quote"