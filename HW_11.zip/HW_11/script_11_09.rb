﻿# script_11_09.rb
# Using "puts" display number of characters in statement – This statement contains " double quote and ' single quote (Page # 5; using .length)

puts "Number of characters in statement is:"
puts "\a This statement contains \" double quote and \' single quote".length
