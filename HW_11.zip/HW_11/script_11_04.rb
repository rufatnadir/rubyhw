﻿#	script_11_04.rb
#	Using only 1 "puts" to display multiline statement (using \n, second line uses Indent with tabs, use \t)

puts "This is a multiline statement\n \tusing multiple puts commands \nfor each line!"
