﻿# script_11_07.rb
# Using "puts" display statement – This statement contains \ backslash

puts "This statement contains \\ backslash"
