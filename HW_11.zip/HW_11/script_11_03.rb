﻿# script_11_03.rb
# Using "puts" for every line, display statement (second line uses Indent with tabs, use \t)

puts "This is a multiline statement"
puts "\tusing multiple puts commands"
puts "For each line"
