﻿# script_11_01.rb
# Using "puts" display statement – Hello World!

puts "Hello World!"
