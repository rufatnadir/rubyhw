﻿# script_11_05.rb
# Using heredoc and "puts" to display multiline statement (second line uses Indent with tabs)

puts <<EOF
This is a multiline statement
  using multiple puts commands
for each line!
EOF
    