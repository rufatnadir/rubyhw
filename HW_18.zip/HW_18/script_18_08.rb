﻿# script_18_08.rb
# Display the first item in the following range: from cab to cat

range = ("cab" .. "cat")

puts "First item of a range is: #{range.to_a.first}"
