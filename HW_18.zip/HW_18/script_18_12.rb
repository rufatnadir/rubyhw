﻿# script_18_12.rb
# Display the size (how many items) in the following range: from a to z

range = ("a" .. "z")
puts "Range contains #{range.to_a.size} items"
