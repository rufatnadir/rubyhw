﻿# script_18_05.rb
# Display the following range: from a to z

range  = ("a".."z")
puts "Range is #{range.to_a}"
