﻿# script_17_01.rb
# Display the following range:  from 1 to 10

range = (1 .. 10)

puts range.to_a
