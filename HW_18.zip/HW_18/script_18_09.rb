﻿# script_18_09.rb
# Display the last item in the following range: from cab to cat

range = ("cab" .. "cat")

puts "Last item of a range is: #{range.to_a.last}"