﻿# script_18_06.rb
# Display the following range: from cab to cat

range = ("cab" .. "cat")

puts "Range is: #{range.to_a}"
