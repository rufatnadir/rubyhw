﻿# script_18_14.rb
# Ranges as Sequences: Display the size (how many items) in the following range: from aaa to zzz

range = ('aaa' .. 'zzz')
puts range
puts "Range contains #{range.to_a.size} items"

