﻿# script_18_13.rb
# Display the size (how many items) in the following range: from aa to zz

range = ('aa' .. 'zz')
puts range
puts "Range contains #{range.to_a.size} items"
