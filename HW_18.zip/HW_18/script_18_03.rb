﻿# script_17_03.rb
# Display the minimum item in the following range: from 1 to 768

range = (1 .. 768)
puts "Range is #{range}"
puts "Minimum item of range is #{range.min}"
