﻿# script_18_04.rb
# Display the maximum item in the following range: from 1 to 768

range = (1 .. 768)
puts "Range is #{range}"
puts "Maximum item of range is #{range.max}"