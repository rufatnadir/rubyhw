﻿# script_18_07.rb
# Display the size (how many items) in the following range: from cab to cat

range = ("cab" .. "cat")

puts "Size of range is: #{range.to_a.size}"
