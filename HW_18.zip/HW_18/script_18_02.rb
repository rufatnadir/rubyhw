﻿# script_17_02.rb
# Display the following range excluding end point: from 1 to 10

range = (1 ... 10)
puts "Range is #{range}"
puts "Range excliuding end point: #{range.to_a}"


