﻿# script_20_05.rb
=begin
a.	Create method "calc_sum_two" with parameters "first" and "second" and do following:
b.	Call this method with parameters "first" and "second" and values 5 and 17 correspondently
=end

def calc_sum_two(first, second)
  puts "The sum of #{first} and #{second} is #{first + second}"
end

calc_sum_two(17, 78)

