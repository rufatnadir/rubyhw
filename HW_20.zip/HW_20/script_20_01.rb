﻿# script_20_01.rb
=begin
a.	Create method "my_method" with following:
	1.	Define method "my_method"
	2.	Variable "name" has value "Your Name".
	3.	Print the statement: Hello your name (using variable) plus an exclamation mark.
b.	Call this method
=end

# a
# 1
def my_method
end

# 2
def my_method
   name = "Rufat Nadir" 		# My name here
end

# 2
def my_method
   name = "Rufat Nadir"
   print "Hello #{name}!"
end

# b.	Call this method
my_method