﻿# script_20_02.rb
=begin
a.	Create method "my_method_param" with parameter "name" and do following:
	1.	Define method "my_method_param"
	2.	Print the statement: Hello your name (using variable) plus an exclamation mark.
b.	Call this method with passing parameter "name" with value - "Your Name"
=end

def my_method_param(name) #Define method "my_method_param"
  print "Hello #{name}!"
end

my_method_param ("Rufat")

