﻿# script_15_05.rb
# Display result of the assignment using /= operator of following variables:  c /= a

c = 10
a = 3
c /= a

puts "result of the assignment using /= operator of following variables:  c /= a: #{c}"