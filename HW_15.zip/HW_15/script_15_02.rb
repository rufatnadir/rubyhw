﻿# script_15_02.rb
# Display result of the assignment using += operator of following variables:  c += a

a = 10
c = 7
c += a

puts "Result of the assignment using \"+=\" operator:  c += a is c = #{c}"

