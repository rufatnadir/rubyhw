﻿# script_15_03.rb
# Display result of the assignment using -= operator of following variables:  c -= a

c = 5
a = 9
c -= a
puts "Result of the assignment using \-=\ operator: c -= a is: #{c}"