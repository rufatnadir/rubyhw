﻿# script_15_06.rb
# Display result of the assignment using %= operator of following variables:  c %= a

c = 20
a = 3
c %= a

puts "result of the assignment using %= operator of following variables:  c %= a: c = #{c}"
