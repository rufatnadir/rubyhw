﻿# script_15_06.rb
# Display result of the assignment using **= operator of following variables:  c **= a

c = 5
a = 6
c **= a

puts "Result of the assignment using **= operator of following variables:  c **= a: c = #{c}"
