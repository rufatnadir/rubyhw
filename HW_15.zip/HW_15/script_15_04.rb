﻿# script_15_04.rb
# Display result of the assignment using *= operator of following variables:  c *= a

c = 4
a = 6
c *= a
puts "Result of the assignment using \*=\ operator: c *= a: c = #{c}"