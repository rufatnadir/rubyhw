﻿# script_15_01.rb
# Display result of the assignment using = operator of following variables:  c = a + b

a = 10
b = 3
c = a + b

puts "Result of the assignment using \"=\" operator of #{a} and #{b} variables where c = a + b: c = #{c}"
